@extends('layouts.main')

@section('container')
<div class="aboutpage text-light">
    <center>
        <div class="row text-center justify-content-center py-5">
            <div class="col-md-6">
                <h2>Licoworks adalah platform end solution untuk event ecosystem, kami menyediakan layanan pembuatan, promosi, hingga penjualan tiket dalam sekali jalan dan semuanya ada di genggaman anda</h2>
            </div>
        </div>
    </center>
</div>


@endsection
