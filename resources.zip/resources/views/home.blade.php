@extends('layouts.main')

@section('container')
<div class="Homepage">
    <div class="row">
        <div class="col-lg-8">


    <p>POP ART TOWN EVENT <img src="/image/linetext.png" style="margin-top: 100px; position:relative; margin-left:-150px; margin-top:60px"><br>Presented By. After Rain</p>
</div>
<div class="contenttext">
    <p>After Rain adalah sebuah komunitas peminat <br> kebudayaan Jepang berdiri semenjak 2018  <br>dengan orang – orang yang sudah menyukai  <br>budaya Jepang semenjak  menempuh jenjang  <br>sekolah formal

    </p>
    <div class="buy">
        <a class="btn w3-left w3-margin-right py-2" href="/posts/pop-art-town"> Detail <i class="bi bi-arrow-right-square"></i></a>
        <span  class="date">Juli 23, 2022</span> <br> <img src="/image/location.png" width="24" height="24" ><span class="location">Amlapura, Indonesia</span>
    </div>
</div>

</div>
</div>

@endsection
