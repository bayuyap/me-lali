@extends('layouts.main')

@section('container')
<main class="form-payment">
    <form>
        <center>
      <img class="mb-4" src="image/lico.png" alt="" width="300" height="300">
        </center>
    </form>
  </main>
@endsection
