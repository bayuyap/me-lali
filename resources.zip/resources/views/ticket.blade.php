@extends('layouts.main')

@section('container')
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <center>
            <div class="font-text text-light mb-5">
            <h1 style="font-size:50px; font-family:sans-serif"><b> After Rain Ticket</b></h1>
            <h1 style="font-size:50px; font-family:sans-serif"><b> Please show the QRCode <br> to Enter the event </b></h1>
        </div>

            <img class="mb-4" src="image/ticketAR.png" alt="" width="500" height="500">
            </center>
        </div>
    </div>
</div>
@endsection
